package com.buffalo.controlefinancas.util;

public interface ActionMaps {
    void mapComponents();
    void mapComponentActions();
}
