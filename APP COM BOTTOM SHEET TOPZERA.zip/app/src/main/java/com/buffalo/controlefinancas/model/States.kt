package com.buffalo.controlefinancas.model

import com.google.gson.annotations.SerializedName

class States {
    @SerializedName("estados")
    var states : MutableList<State>? = null
}