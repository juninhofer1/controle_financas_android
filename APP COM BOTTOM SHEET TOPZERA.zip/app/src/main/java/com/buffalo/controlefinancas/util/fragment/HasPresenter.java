package com.buffalo.controlefinancas.util.fragment;

public interface HasPresenter<T extends Presenter> {

    T getPresenter();
}
