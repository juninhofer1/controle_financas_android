package com.buffalo.controlefinancas

import android.app.Application
import com.example.controlefinancas.database.ExpenseTypeDAO
import com.buffalo.controlefinancas.model.ExpenseType
import io.realm.Realm
import io.realm.RealmConfiguration

class MainApplication : Application() {

    private var mRealmConfiguration: RealmConfiguration? = null

    override fun onCreate() {
        super.onCreate()
        Realm.init(this)
        Realm.setDefaultConfiguration(getRealmConfiguration())

        createFirstType()
    }

    fun getRealmConfiguration(): RealmConfiguration? {
        if (mRealmConfiguration == null) {
            mRealmConfiguration = RealmConfiguration.Builder()
                .name(getRealmName())
                .schemaVersion(getSchemaVersion())
                .deleteRealmIfMigrationNeeded()
                .build()
        }
        return mRealmConfiguration
    }

    fun createFirstType() {
        ExpenseTypeDAO.update(ExpenseType(1, "Alimentação", "#9FE2BF"))
        ExpenseTypeDAO.update(ExpenseType(2, "Combustível", "#FF7F50"))
        ExpenseTypeDAO.update(ExpenseType(3, "Hospedagem",  "#CCCCFF"))
        ExpenseTypeDAO.update(ExpenseType(4, "Transporte", "#f54275"))
        ExpenseTypeDAO.update(ExpenseType(5, "Aluguel", "#42f54e"))
    }

    fun getRealmName(): String {
        return Realm.DEFAULT_REALM_NAME
    }

    fun getSchemaVersion(): Long {
        return BuildConfig.VERSION_CODE.toLong()
    }
}