package com.buffalo.controlefinancas.util

interface MapElement {
    fun mapComponents()
    fun mapActionComponents()
}