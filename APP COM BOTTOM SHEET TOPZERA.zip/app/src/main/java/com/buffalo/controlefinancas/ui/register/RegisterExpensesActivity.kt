package com.buffalo.controlefinancas.ui.register

import android.annotation.SuppressLint
import android.app.DatePickerDialog
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.buffalo.controlefinancas.databinding.ActivityRegisterBinding
import com.buffalo.controlefinancas.model.ExpenseType
import com.buffalo.controlefinancas.model.States
import com.buffalo.controlefinancas.ui.BottonSheetExpense
import com.buffalo.controlefinancas.util.DateUtil
import com.buffalo.controlefinancas.util.LiterUtil
import com.buffalo.controlefinancas.util.MapElement
import com.buffalo.controlefinancas.util.MonetaryUtil
import com.google.gson.Gson
import org.json.JSONException
import org.json.JSONObject
import java.io.IOException
import java.io.InputStream
import java.util.*


class RegisterExpensesActivity : AppCompatActivity(), MapElement, BottonSheetExpense.Listener {

    private lateinit var binding: ActivityRegisterBinding
    private var expenseType : ExpenseType? = null
    private var calendar : Calendar = Calendar.getInstance()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mapComponents()
        showDisplayValues()
        mapActionComponents()

        try {
            val obj = JSONObject(loadJSONFromAsset())
            val gson = Gson()

            val states = gson.fromJson(obj.toString(), States::class.java)

        } catch (e: JSONException) {
            e.printStackTrace()
        }
    }

    fun loadJSONFromAsset(): String? {
        val json: String? = try {
            val inputStrem: InputStream = getAssets().open("cidades_estados.json")
            val size: Int = inputStrem.available()
            val buffer = ByteArray(size)
            inputStrem.read(buffer)
            inputStrem.close()
            String(buffer, charset("UTF-8"))
        } catch (ex: IOException) {
            ex.printStackTrace()
            return null
        }
        return json
    }



    fun showBottonSheet() {
        val lScheduleOptionsFragment: BottonSheetExpense =
            BottonSheetExpense.newInstance(this)
        lScheduleOptionsFragment.show(supportFragmentManager, null)
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return super.onSupportNavigateUp()
    }

    fun showDisplayValues() {
        binding.editTextDate.setText(DateUtil.data("dd/MM/yyyy", calendar.time))
    }

    override fun mapComponents() {
        binding = ActivityRegisterBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.mainToolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.setDisplayShowHomeEnabled(true)
    }

    @SuppressLint("SetTextI18n")
    override fun mapActionComponents() {
        val c = Calendar.getInstance()
        val year = c.get(Calendar.YEAR)
        val month = c.get(Calendar.MONTH)
        val day = c.get(Calendar.DAY_OF_MONTH)

        binding.editTextValue.addTextChangedListener(MonetaryUtil(binding.editTextValue))
        binding.editTextLiter.addTextChangedListener(LiterUtil(binding.editTextLiter))
        binding.editTextExpenseType.setOnClickListener {
            showBottonSheet()
        }

        binding.editTextDate.setOnClickListener {
            val dpd = DatePickerDialog(this, { _, year, monthOfYear, dayOfMonth ->
                calendar.set(Calendar.DAY_OF_MONTH, dayOfMonth)
                calendar.set(Calendar.MONTH, month)
                calendar.set(Calendar.YEAR, year)
                binding.editTextDate.setText(DateUtil.data("dd/MM/yyyy", calendar.time))
            }, year, month, day)
            dpd.show()
        }
    }

    override fun onItemClick(aAtividade: ExpenseType?) {
        expenseType = aAtividade
        binding.editTextExpenseType.setText(aAtividade?.descricao)
        if(aAtividade!!.descricao.equals("Combustível")) {
            binding.textImputLiter.visibility = View.VISIBLE
        } else {
            binding.textImputLiter.visibility = View.GONE
        }
    }
}