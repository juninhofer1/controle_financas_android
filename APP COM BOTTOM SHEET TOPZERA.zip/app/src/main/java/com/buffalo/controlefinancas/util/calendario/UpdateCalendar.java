package com.example.controlefinancas.util.calendario;

public interface UpdateCalendar {
    void updateEvent();
}
