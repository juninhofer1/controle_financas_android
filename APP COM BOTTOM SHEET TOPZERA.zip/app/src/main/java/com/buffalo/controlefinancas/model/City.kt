package com.buffalo.controlefinancas.model

open class City {
    var sigla : String? = ""
    var anme : String? = ""
    var cities : MutableList<City>? = null
}