package com.buffalo.controlefinancas.util

import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.widget.EditText
import java.math.BigDecimal
import java.text.NumberFormat
import java.util.*

class MonetaryUtil @JvmOverloads constructor(val campo: EditText, divisor: Int = 100, numberFormat: NumberFormat = NumberFormat.getCurrencyInstance()) : TextWatcher {
    private var current = ""
    private val divisor: Int

    //Pega a formatacao do sistema, se for brasil R$ se EUA US$
    private val nf: NumberFormat
    override fun onTextChanged(aCharSequence: CharSequence, start: Int, before: Int, count: Int) {
        if (aCharSequence.toString() != current) {
            try {
                val parsed = aCharSequence.toString().replace("[R$,.\\s]".toRegex(), "").toDouble()
                current = nf.format(if (divisor == 0) parsed else parsed / divisor)
                campo.setText(current)
                campo.setSelection(current.length)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {}

    override fun afterTextChanged(s: Editable) {}

    companion object {

        val locale = Locale("pt", "BR")

        @JvmOverloads
        fun convertFormatStringForDouble(value: String, divisor: Int = 100): Double {
            val cleanString = value.replace("[R$,.\\s]".toRegex(), "")
            val parsed = cleanString.toDouble()
            return if (divisor == 0) parsed else parsed / divisor
        }

        fun createStringLitragem(aValue: String, divisor: Int, numberFormat: NumberFormat): String {
            if (divisor > 0) {
                numberFormat.minimumFractionDigits = divisor
                numberFormat.maximumFractionDigits = divisor
            } else {
                numberFormat.minimumFractionDigits = 0
                numberFormat.maximumFractionDigits = 0
            }
            val value = aValue.replace("[R$]".toRegex(), "")
            val parsed = value.replace("[,]".toRegex(), ".").toDouble()
            return numberFormat.format(parsed)
        }

        fun format(aDoubleValue: Double?, aDivider: Int): String {
            val lNumberFormat = NumberFormat.getCurrencyInstance()
            if (aDivider > 0) {
                lNumberFormat.minimumFractionDigits = aDivider
                lNumberFormat.maximumFractionDigits = aDivider
            } else {
                lNumberFormat.minimumFractionDigits = 0
                lNumberFormat.maximumFractionDigits = 0
            }
            return lNumberFormat.format(aDoubleValue)
                .replace("-", "- ")
        }

        fun getCurrencyTransfer(value: Double): String {
            val numberFormat = NumberFormat.getCurrencyInstance()
            numberFormat.maximumFractionDigits = 2
            return numberFormat.format(value)
        }
    }

    init {
        campo.inputType = InputType.TYPE_CLASS_NUMBER
        this.divisor = divisor
        nf = NumberFormat.getCurrencyInstance(Locale("pt", "BR"))
        if (divisor > 0) {
            nf.minimumFractionDigits = BigDecimal(divisor / 10).precision()
            nf.maximumFractionDigits = BigDecimal(divisor / 10).precision()
        } else {
            nf.minimumFractionDigits = 0
            nf.maximumFractionDigits = 0
        }
    }
}

fun Double.formatDoubleMoneyToString(): String{
    val numberFormat = NumberFormat.getCurrencyInstance(Locale("pt", "BR"))
    return numberFormat.format(this)
}