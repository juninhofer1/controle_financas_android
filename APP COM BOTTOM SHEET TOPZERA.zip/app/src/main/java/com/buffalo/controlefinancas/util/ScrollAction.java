package com.buffalo.controlefinancas.util;

public interface ScrollAction {
    void moveUp();
    void moveDown();
}