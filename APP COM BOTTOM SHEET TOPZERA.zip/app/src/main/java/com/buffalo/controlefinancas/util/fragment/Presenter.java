package com.buffalo.controlefinancas.util.fragment;

public interface Presenter {

    void resume();

    void pause();

    void destroy();
}
