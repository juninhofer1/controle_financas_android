package com.corporacao.capsula.componentes.fragment;

public interface Presenter {

    void resume();

    void pause();

    void destroy();
}
